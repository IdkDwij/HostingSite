<?php 
	require('anti_ddos/start.php');
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/main.css">
		<title>Games frfr</title>
	</head>
	<body>
	<a href="supersmashflash">Super Smash Flash</a>
	</body>
</html>
