<?php 
	require('anti_ddos/start.php');
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Super Smash Flash frfr</title>
	</head>
<body>

<object width="100%" height="auto"></object>
<embed src="Super-Smash-Flash.swf" width="100%" height="auto"></embed>

</body>
</html>
